--binding/winapi: loader for winapi.init (or the demo if run standalone)
if not ... then require'winapi_demo'; return end
return require'winapi.init'
